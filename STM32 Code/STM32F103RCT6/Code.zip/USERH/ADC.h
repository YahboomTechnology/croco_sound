#ifndef __ADC_H__
#define __ADC_H__

#include "stm32f10x.h"

void ADC1_Init(void);//ADC1初始化
uint16_t ADC1_Result(void);//获取ADC转换数据

#endif
