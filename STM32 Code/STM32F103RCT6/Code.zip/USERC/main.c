#include "stm32f10x.h"
#include "SysTick.h"
#include "UART.h"
#include "ADC.h"

int main(void)
{
    uint16_t ADC_Result;
    float ADC_Value;
    
    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
    ADC1_Init();//ADC1初始化
    
    printf("Ambient sound measurement!\n");//打印环境声音测量！
    
    while(1)
    {
        ADC_Result = ADC1_Result();//获取ADC转换数据
        printf("ADC_Result = %d\r\n",ADC_Result);//打印ADC转换数据
        
        //将声音大小转换成0-100等级
        ADC_Value = ADC_Result * 100 / 4095;//数据转换
        printf("ADC1_Value = %0.2f\r\n",ADC_Value);//打印音量对应等级
        Delay_us(100000);//延时100ms 时间越短 串口打印的数据更快，更实时
    }
}
